Thanks for downloading! I hope you enjoy :)

Lucario_Overhaul_Assets should go into your resource packs folder

Lucario_Overhaul_Data should go into your world's datapack folder